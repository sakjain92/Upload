# Replace with course website
WEB_ADDR='https://github.com/sakjain92/Upload'
TEMP_DIR='temp'
ALL_FILE=`printf "%s/.all_files.txt" "$TEMP_DIR"`
MD5SUM_FILE=`printf "%s/.md5sum.txt" "$TEMP_DIR"`
ONLINE_MD5SUM_FILE=`printf "https://raw.githubusercontent.com/sakjain92/Upload/master/%s" "$MD5SUM_FILE"`
# Timeout in seconds for wget to try to connect
WGET_TIMEOUT=5

# List of files which are being tracked
declare -a files=(
		"file1.txt"
		"dir/file2.txt"
		"Makefile"
		"check_updates.sh"
		)

mkdir -p $TEMP_DIR
rm -rf $ALL_FILE

# Get the online md5sum file
echo $ONLINE_MD5SUM_FILE
wget $ONLINE_MD5SUM_FILE -T $WGET_TIMEOUT -O $MD5SUM_FILE


for file in "${files[@]}"
do
	cat "$file" >> $ALL_FILE
done

all_md5sum=`md5sum $ALL_FILE | awk '{print $1;}'`
echo "$all_md5sum"

